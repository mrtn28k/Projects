import logo from "./logo.png";
import hero from "./hero.png";
import logo2 from "./logo2.png";
import qr from "./demoqr.png";
import astro from "./astronaut.png";
import lpu from "./lpu.png";
import cse from "./cse.png";
import robots from "./robots.png";
import swiggy from "./swiggy.png";
import lpuLogo from "./lpuLogo.png";
import microsoft from "./microsoft.png";
import es from "./es.png";
import profile from "./profile.png";
import hero1 from "./hero1.png";
import hero2 from "./hero2.png";

export {
  logo,
  hero,
  logo2,
  qr,
  astro,
  lpu,
  cse,
  robots,
  swiggy,
  lpuLogo,
  microsoft,
  es,
  profile,
  hero1,
  hero2,
};
