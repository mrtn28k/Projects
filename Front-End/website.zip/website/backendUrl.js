export const BACKEND_URL =
  "https://asia-southeast2-technon-534f.cloudfunctions.net/api";
