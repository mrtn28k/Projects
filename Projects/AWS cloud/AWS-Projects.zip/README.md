# AWS Projects Portfolio

Welcome to my AWS Projects Portfolio! This repository is a showcase of my proficiency in leveraging various AWS services through a collection of well-structured projects. Each project is neatly organized within its dedicated directory, offering insights into my AWS skills and capabilities.





## Projects Overview

Explore the diverse range of projects featured in this portfolio:

### Project 1: Data Visualization with AWS QuickSight and S3

- **Description:** This project focuses on visualizing data using AWS QuickSight sourced from AWS S3.
- **Technologies Used:** AWS S3, AWS QuickSight.


### Project 2: S3 Static Website

- **Description:** Hosting a static website on AWS S3.
- **Technologies Used:** AWS S3.


### Project 3: CI-CD on AWS

- **Description:** Cretating a CI- CD pipeline on AWS using AWS CodePipeline
- **Technologies Used:** AWS CodePipeline, GitHub.


### Project 4: Scheduling EC2 Instances for Off-Hours

- **Description:** Starting and stopping EC2 instances based on a time schedule, including IaC
- **Technologies Used:** AWS Lambda, AWS EventBridge, AWS EC2, AWS IAM, Terraform


### Project 5: Serverless Web App Development

- **Description:** Deploying a serverless Web-App
- **Technologies Used:** AWS Amplify, AWS Lambda, API Gateway, DynamoDB, AWS IAM


### Project 6: 12weeksworkshop

- **Description:** A series of AWS projects under the [12 Weeks Workshop Challenge](https://12weeksworkshops.com/), organized by [AWS USER GROUP YAOUNDE](https://www.linkedin.com/company/aws-user-group-yaounde/)
- **Technologies Used:** AWS Amplify, AWS Lambda, API Gateway, DynamoDB, AWS IAM

### Project 7: Inventory Management

- **Description:** Deploying serverless archicture to inform when inventory levels are low
- **Technologies Used:** AWS Lambda, DynamoDB, AWS IAM, AWS S3, AWS SNS




Thank you for visiting my AWS Projects Portfolio! I trust you'll find these projects not only informative but also inspiring.

---
