---
title: "AWS CloudFormation Workshop"
weight: 1
---

![aws-cloudformation](/static/aws-cloudformation.png)

#### Welcome to the AWS CloudFormation Workshop!

The intent of this workshop is to educate builders about the features of [AWS
CloudFormation](https://aws.amazon.com/cloudformation/) and how to get started building quickly.

A background in CloudFormation, command line, git, and development workflows is not required.
