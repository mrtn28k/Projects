command="git receive-pack $*"
exec $command