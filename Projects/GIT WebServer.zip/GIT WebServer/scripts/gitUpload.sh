command="git upload-pack $*"
exec $command