module.exports = {

};

exports.gitHooks = function () {
    
};