exports.forgotPassword = function(){
    var sgMail = require('@sendgrid/mail');
};