module.exports = function (apiRoute) {
    //TODO : Add API call features
    return apiRoute;
};