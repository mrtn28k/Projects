1.The file that contain the main is " Medical.java "

2. Before compiling and running this file, plsease create the required tables.
using the file "table.lst". 
i.e.SQL>@"<path>\table.lst"

3. Make sure the jdk and ojdbc path are set 
	